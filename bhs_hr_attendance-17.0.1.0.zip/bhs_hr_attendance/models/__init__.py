# -*- coding: utf-8 -*-

from . import resource_calendar
from . import hr_attendance
from . import attendance_location
from . import hr_employee
from . import res_users